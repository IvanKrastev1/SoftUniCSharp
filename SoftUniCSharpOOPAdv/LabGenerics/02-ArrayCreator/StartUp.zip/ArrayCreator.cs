﻿public class ArrayCreator
{
    static public T[] Create<T>(int lenght, T element)
    {
        return new T[lenght];
    }

}