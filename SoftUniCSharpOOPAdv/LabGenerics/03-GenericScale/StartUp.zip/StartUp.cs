﻿
    using System;

class StartUp
    {
       public  static void Main()
        {
        }
    }

