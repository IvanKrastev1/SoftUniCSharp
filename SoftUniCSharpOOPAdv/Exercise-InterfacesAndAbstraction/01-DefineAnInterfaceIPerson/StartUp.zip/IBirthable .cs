﻿ public interface IBirthable 
    {
        string Birthday { get; }
    }
