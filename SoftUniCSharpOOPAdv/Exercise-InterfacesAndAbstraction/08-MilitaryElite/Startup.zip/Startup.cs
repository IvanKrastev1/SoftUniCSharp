﻿using Problem8_MilitaryElite.Core;

namespace Problem8_MilitaryElite
{
    class Startup
    {
        private static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}