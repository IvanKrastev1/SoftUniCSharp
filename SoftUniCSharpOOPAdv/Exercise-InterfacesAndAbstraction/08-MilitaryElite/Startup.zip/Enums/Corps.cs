﻿namespace Problem8_MilitaryElite.Enums
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}