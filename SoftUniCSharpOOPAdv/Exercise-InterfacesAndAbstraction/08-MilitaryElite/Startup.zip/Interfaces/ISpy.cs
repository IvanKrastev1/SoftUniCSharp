﻿namespace Problem8_MilitaryElite
{
    public interface ISpy
    {
        int CodeNumber { get; }
    }
}