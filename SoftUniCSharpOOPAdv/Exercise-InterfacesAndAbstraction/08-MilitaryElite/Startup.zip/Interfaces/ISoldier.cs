﻿namespace Problem8_MilitaryElite
{
    public interface ISoldier
    {
        string FirstName { get; }
        string Id { get; }
        string LastName { get; }
    }
}