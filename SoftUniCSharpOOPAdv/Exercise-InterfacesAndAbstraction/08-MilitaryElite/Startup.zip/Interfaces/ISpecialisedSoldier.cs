﻿using Problem8_MilitaryElite.Enums;

namespace Problem8_MilitaryElite
{
    public interface ISpecialisedSoldier
    {
        Corps Corps { get; }
    }
}