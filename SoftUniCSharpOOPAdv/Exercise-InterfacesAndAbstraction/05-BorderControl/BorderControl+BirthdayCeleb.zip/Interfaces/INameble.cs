﻿public interface INameble
    {
        string Name { get; }
    }