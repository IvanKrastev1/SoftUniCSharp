﻿using System;

public interface IBeing
{
    string Id { get; }
    
}