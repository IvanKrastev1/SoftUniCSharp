﻿public interface IBeing
{
    string Id { get; }
}