﻿namespace _7_FoodShortage.Interfaces
{
    public interface IBuyer
    {
        int Food { get; set; }
        void BuyFood();
    }
}