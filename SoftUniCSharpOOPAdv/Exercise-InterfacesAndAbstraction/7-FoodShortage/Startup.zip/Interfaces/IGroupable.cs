﻿ public interface IGroupable
    {
        string GroupName { get; }
    }