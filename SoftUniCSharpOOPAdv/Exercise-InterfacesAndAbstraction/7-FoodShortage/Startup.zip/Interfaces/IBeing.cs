﻿using System;

public interface IBeing
{
    string Name { get; }
    int Age { get; }

}