﻿public enum CoffeePrice
    {
      None,
      Small = 50,
      Normal = 100,
      Double = 200
    }
