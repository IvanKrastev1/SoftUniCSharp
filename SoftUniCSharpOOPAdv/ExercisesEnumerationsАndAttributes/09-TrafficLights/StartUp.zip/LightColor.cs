﻿public enum LightColor
{
    Red,
    Green,
    Yellow
}
