﻿[Type("Suit", "Provides suit constants for a Card class.")]
public enum Suit
{
    Clubs ,
    Diamonds, 
    Hearts ,
    Spades 
}
